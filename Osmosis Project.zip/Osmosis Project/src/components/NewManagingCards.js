import React from 'react';
import '../css/Cards.css';
import CardItem from './CardItem';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';



function NewBlogCards(props) {

  const responsive = {
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 5,
      slidesToSlide: 1 // optional, default to 1.
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 3,
      slidesToSlide: 1 // optional, default to 1.
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1.5,
      slidesToSlide: 1 // optional, default to 1.
    }
  };

 


  return (
    <div className="cards">
      <h1>Managing The Profession</h1>
      <br></br>
      <Carousel
        swipeable={false}
        draggable={false}
        showDots={false}
        responsive={responsive}
        ssr={true} // means to render carousel on server-side.
        infinite={true}
        autoPlay={props.deviceType !== "mobile" ? true : false}
        autoPlaySpeed={100000}
        keyBoardControl={true}
        customTransition="all .5"
        transitionDuration={500}
        containerClass="carousel-container"
        removeArrowOnDeviceType={["tablet", "mobile"]}
        deviceType={props.deviceType}
        dotListClass="custom-dot-list-style"
        itemClass="carousel-item-padding-40-px"

      >

<div><CardItem
          src='images/11.jpg'
          text='Successfully Manage Hybrid and Remote..'
          path='/services'
        /></div>
        <div><CardItem
          src='images/12.jpg'
          text='Introduction to Artificial Intelligence for project..'
          path='/services'
        /></div>
        <div><CardItem
          src='images/13.jpg'
          text='Timeless Leadership Principles'
          path='/services'
        /></div>
        <div><CardItem
          src='images/14.jpg'
          text='Scheduling your priorities'
          path='/products'
        /></div>
         </Carousel>
    </div>
  );
}

export default NewBlogCards;