import React from 'react'
import CourseContent from './CourseContent'
export default function CourseDetail() {
    return (""
    )
}

