import React from 'react';
import '../../App.css'

import AllCoursesCards from '../AllCoursesCards'

function Home(props) {
    return (
        <>
            <AllCoursesCards />
            
        </>
    );
}

export default Home;